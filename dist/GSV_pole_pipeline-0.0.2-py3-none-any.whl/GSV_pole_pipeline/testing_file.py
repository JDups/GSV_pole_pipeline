def greeting(name):
    print("Hello, " + name)
