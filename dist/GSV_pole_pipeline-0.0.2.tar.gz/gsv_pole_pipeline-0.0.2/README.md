# GSV-pole-pipeline

The package can be installed with pip.
```
!pip install git+https://git@github.com/JDups/GSV_pole_pipeline.git
```
Or by cloning the repo yourself.



Documentation coming shortly