from setuptools import setup

setup(
    name="gsv_pole_pipeline",
    version="0.0.2",
    description="A small example package",
    url="https://github.com/JDups/GSV_pole_pipeline",
    author="Jonathan Dupuis",
    author_email="jon.c.dupuis@gmail.com",
    license="MIT",
    packages=["gsv_pole_pipeline"],
    zip_safe=False,
)
